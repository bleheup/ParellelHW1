Instructions:

For DiningPhilosopherV1.cpp, DiningPhilosopherV2.cpp, DiningPhilosopherV3.cpp:

no user inputs are required. 

To compile the program using: 

g++ -std=c++17 DiningPhilosophersV1.cpp

Which is for my machine that didn't compile source code by default with c++17

If c++17 is installed 

g++ DiningPhilosophersV1.cpp

Will work just fine. 
Just adjust version numbers accordingly




For DiningPhilosopherV4.cpp:

g++ -std=c++17 DiningPhilosophersV1.cpp

Which is for my machine that didn't compile source code by default with c++17

If c++17 is installed 

g++ DiningPhilosophersV4.cpp

