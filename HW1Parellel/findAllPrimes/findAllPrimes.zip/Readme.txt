findAllPrimes.cpp is source code that provides prime number information between 1 and 100 000 000. The information provided below. 

<execution time>
<total number of primes found>
<sum of all primes found> 
<top ten maximum primes, listed in order from lowest to highest>

On my Mac I had to fun the following command: 

g++ -std=c++17 findAllPrimes.cpp

I believe if you have c++17 on your machine you should be able to use the following command:

g++ findAllPrimes.cpp

After compiling the code you execute the code by using the following command:

./a.out